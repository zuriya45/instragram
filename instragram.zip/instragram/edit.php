<?php
session_start();
if(!isset($_SESSION['login'])){
    header("location:login.php?pesan=logindulu");
}
include "koneksi.php";

$no = $_GET['no'];
$sql = "SELECT * FROM post WHERE no = '$no' ";
$query = mysqli_query($koneksi, $sql);
while ($post = mysqli_fetch_assoc($query)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
   
    <div class="container mt-5">
    <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" class="form-control" value="<?= $post['gambar'] ?>">
     

        <div class="mb-3">
        <label for="">Foto</label>
        <input type="file" name="gambar" id="" class="form-control" value="<?= $post['gambar'] ?>" ><br>
        </div>
        
        <div class="mb-3">
        <label for="">CAPTION</label>
        <input type="text" name="caption" id="" class="form-control" value="<?= $post['caption'] ?>" autocomplete="off"><br>
        </div>

        <div class="mb-3">
        <label for="">LOKASI</label>
        <input type="text" name="lokasi" id="" class="form-control" value="<?= $post['lokasi'] ?>" autocomplete="off"><br>
        </div>
      
        <img src="images/<?= $post['gambar'] ?>" width="100" alt="" ><br><br>

      <button type="submit" value="Update" name="update" class="btn btn-primary">Simpan</button>
    </form>
    </div>
</body>
</html>

<?php } ?>