<?php
session_start();
if(!isset($_SESSION['login'])){
    header("location:login.php?pesan=logindulu");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah</title>
    
<style>
            legend {
                color: white;
                padding: 5px;
                background: #006f6b;
                border-radius: 5px;
            }
            fieldset {
                max-width: 400px;
                border-radius: 10px;
                border-color: #4fffa5;
                background:#FFFFFF;
            }
            label {
                float: left;
            }
            input {
                /* border: none; */
                border-radius: 3px;
                height: 30px;
            }
            input:hover {
                background: #FFFFFF;
            }
            button {
                cursor: pointer;
                color: white;
                background: #ff5f5f;
                width: 100px;
                height: 25px;
                border-radius: 4px;
                border: none;
            }
            button:hover {
                background: #ff2e2e;
            }
            label {
                color: dark;
            }
        </style>
    </head>
    <body>
        <div align="center">
            <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
                <fieldset>
                    <legend>Tambah Cerita</legend>
                    <p>
                        <label for="">Masukan Gambar</label>
                        <input type="file" name="gambar" id="" required><br><br>
                    </p>
                    <p>
                        <label for="" style="margin-right: 25px;"> caption </label>
                        <input type="text" name="caption" required placeholder="caption"/>
                    </p>
                    <p>
                        <label for="" style="margin-right: 33px;">Lokasi</label>
                        <input type="text" name="lokasi" required  placeholder="lokasi"/>
                    </p>
                    <p>
                     <input type="submit" value="simpan" name="simpan">
                    </p>
                </fieldset>
            </form>`

</body>
</html>