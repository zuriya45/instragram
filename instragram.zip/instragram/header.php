
<nav class="navbar navbar-expand-lg bg-dark sticky-top">
            <div class="container-fluid">
            <font color="white" style="font-style: italic;font-family: FontAwesome;">Boboiboy</font>
              </div>
             <ul>
             <button type="button" id = "addEventListener" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="fa-solid fa-circle-plus"></i></button>
          </ul>
          <ul>
         <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#logoutModal">
        <i class="fa-solid fa-right-from-bracket"></i>
    </button>
</ul>
</nav>

<!-- Logout Dikonfirmasi Modal -->
<div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header" style="background-color: crimson;">
                <h5 class="modal-title" id="exampleModalLabel">Logout</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Apakah Anda Yakin Ingin Logout?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <a href="logout.php" class="btn btn-danger" id="logoutButton">Logout</a>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const logoutButton = document.getElementById("logoutButton");

        logoutButton.addEventListener("click", function (e) {
            // Prevent the default behavior of the link (which is redirecting to the logout.php page)
            e.preventDefault();

            // Perform logout logic here (e.g., using AJAX/Fetch API)

            // Assuming the logout is successful, show the SweetAlert
            Swal.fire({
                icon: "success",
                title: "Logout Berhasil!",
                text: "Anda telah berhasil logout.",
                confirmButtonColor: "#3085d6",
                confirmButtonText: "Ok",
            }).then((result) => {
                if (result.isConfirmed) {
                    // Redirect or do something else after the user clicks "Ok"
                    // Example:
                    window.location.href = "logout.php";
                }
            });
        });
    });
</script>


<!-- Modal -->
<!-- Include SweetAlert library -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header" style="background-color: #bf1e9c;">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Cerita</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="myForm" action="proses_tambah.php" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <label for="gambar">Masukkan Gambar</label>
                    <input type="file" name="gambar" id="gambar" class="form-control" required><br>

                    <label for="caption">Caption</label>
                    <input type="text" name="caption" id="caption" class="form-control" required placeholder="Caption">

                    <label for="lokasi">Lokasi</label>
                    <input type="text" name="lokasi" id="lokasi" class="form-control" required placeholder="Lokasi">
                </div>
                <div class="modal-footer">
                    <button type="submit" value="simpan" name="simpan" class="btn btn-dark">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("myForm"); 

    form.addEventListener("simpan", function (e) {
        e.preventDefault();

        // Perform AJAX form submission here, or you can use Fetch API

        // Assuming the form submission is successful, show the SweetAlert
        Swal.fire({
            icon: "success",
            title: "Sukses!",
            text: "Cerita Anda telah berhasil ditambahkan.",
            confirmButtonColor: "#3085d6",
            confirmButtonText: "Ok",
        }).then((result) => {
            if (result.isConfirmed) {
                // Redirect or do something else after the user clicks "Ok"
                // Example:
                window.location.href = "simpan";
            }
        });
    });
});
</script>


   

