<?php
 
 session_start();
if(!isset($_SESSION['login'])){
    header("location:login.php?pesan=logindulu");
}

$server = "localhost";
$username = "root";
$password = "123456";
$database = "db_instragram";

$koneksi = mysqli_connect($server,$username,$password,$database);

?>