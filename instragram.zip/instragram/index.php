<?php
session_start();

if(!isset($_SESSION['login'])){
    header("location:login.php?pesan=logindulu");
}
include "koneksi.php";
$sql = "SELECT * FROM post order by no desc";
$query = mysqli_query($koneksi, $sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Boboboy</title>
</head>
<?php include "header.php"; ?><br><br>
<style>
   body {
    background-color: black;
  }
  /* img {
    padding : 10px;
    width : 300px;
    height : 200px;
    display : block;
    -webkit-transition: 0.4s ease;
    transition:0.4s ease;
    width:700px;
    } */
    img:hover{
      transition:0.4s ease;
      -webkit-transform: scale(1.08);
      transform: scale(1.08);
    }
   
    /* CSS untuk mengubah warna ikon hati */
    .heart-icon {
    color: black; /* Warna awal ikon hati (hitam) */
    }

    /* CSS untuk mengubah warna ikon hati ketika tombol diklik */
    .heart-icon.clicked {
    color: red; /* Warna ikon hati ketika tombol diklik (merah) */
}
    .bookmark-empty {
    color: black; /* Warna awal ikon hati (hitam) */
    }

    /* CSS untuk mengubah warna ikon hati ketika tombol diklik */
    .bookmark-empty.clicked {
    color: black; /* Warna ikon hati ketika tombol diklik (merah) */
}
</style>
<script>
document.addEventListener("DOMContentLoaded", function() {
    const heartButtons = document.querySelectorAll('.heart-button');

    heartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const heartIcon = this.querySelector('.heart-icon');

            // Toggle kelas 'clicked' untuk mengubah warna ikon hati
            heartIcon.classList.toggle('clicked');
        });
    });
});
</script>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const bookmarkButtons = document.querySelectorAll('.bookmark-button');

    bookmarkButtons.forEach(button => {
        button.addEventListener('click', function() {
            const postId = this.getAttribute('data-post-id');

            // Toggle antara kelas 'bookmark-empty' dan 'bookmark-filled'
            this.classList.toggle('bookmark-empty');
            this.classList.toggle('bookmark-filled');

            heartIcon.classList.toggle('clicked');

            // Lakukan sesuatu di sini, seperti mengirim AJAX ke server untuk menyimpan status bookmark
        });
    });
});
</script>

<body>
        
<!-- <p>login berhasil:<?=$_SESSION ['login']?></p> -->
    
        <?php while($post = mysqli_fetch_assoc($query)) { ?>
            <center>
          <div class="wrapper">
		         <div class="zoom-effect">
			          <div class="kotak">
                   <div class="card mt-5 d-inline-block" style="width: 40rem;">
                     <img src="images/<?=$post ['gambar']?>" class="card-img-top" alt="...">
                      <div class="card-body">
                    <p class="card-text"><?=$post ['caption']?></p>
                 </div>
              <ul class="list-group list-group-flush">
             <li class="list-group-item">Lokasi :<?=$post ['lokasi']?></li>
            </ul>
                 
         <div class="card-body">
         <button type="button" class="btn btn-dark heart-button" data-post-id="<?= $post['no'] ?>"><i class="fa fa-heart heart-icon"></i></button>
         <button type="button" class="btn btn-dark bookmark-button bookmark-empty" data-post-id="<?= $post['no'] ?>"><i class="fa-regular fa-bookmark"></i></button>
         <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#exampleModal<?=$post ['no']?>"><i class="fa-solid fa-file-pen fa-beat"></i></button>
         <button class="btn btn-danger btn-xs" onclick="confirmDelete(<?php echo $post['no']; ?>)"><i class="fa-solid fa-trash-can fa-beat"></i></button>
  
   </div>
</div>
</center>

<div class="modal fade" id="exampleModal<?=$post['no']?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header" style="background-color: #bf1e9c;">
                    <h1 class="modal-title fs-5" id="exampleModalLabel ">Edit Cerita</h1>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                           </div>
                               <form action="proses_edit.php" method="post" enctype="multipart/form-data">
                               <div class="modal-body">
                                    <input type="hidden" name="no" value="<?= $post['no'] ?>">
                                    <input type="hidden" name="foto_lama" class="form-control" value="<?= $post['gambar'] ?>">
                                

                                   
                                    <label for="">Foto</label>
                                    <input type="file" name="gambar" id="" class="form-control" value="<?= $post['gambar'] ?>" ><br>
                               
                                    
                                   
                                    <label for="">CAPTION</label>
                                    <input type="text" name="caption" id="" class="form-control" value="<?= $post['caption'] ?>" autocomplete="off"><br>
                               

                                   
                                    <label for="">LOKASI</label>
                                    <input type="text" name="lokasi" id="" class="form-control" value="<?= $post['lokasi'] ?>" autocomplete="off"><br>
                                    </div>
      
                                    <br> <img src="images/<?= $post['gambar'] ?>" width="100" alt="" ><br><br>

                                <div class="modal-footer">
                        <button type="submit" value="update" name="update" class="btn btn-dark">Simpan</button>
                    </div>
                    </form>
            </div>
        </div>
    </div>
<?php } ?>


        <!-- <H2>HALAM UTAMA</H2>
        <button><a class="btn btn-primary" href="tambah.php">Tambah</a></button><br><br>
        <table border = "1">
            <tr>
                <th>NO</th>
                <th>GAMBAR</th>
                <th>CAPTION</th>
                <th>LOKASI</th>
                <th>AKSI</th>
            </tr>

            <?php while($post = mysqli_fetch_assoc($query)) { ?>
                <tr>
                    <td><?=$post ['no'] ?></td>
                    <td><img src="images/<?= $post['gambar'] ?>"  alt="" width="100"></td>
                    <td><?=$post ['caption'] ?></td>
                    <td><?=$post ['lokasi'] ?></td>

                    <td><a class="btn btn-danger" href="hapus.php?no=<?=$post ['no']?>">Hapus</a></td>
                </tr>
                <?php } ?>
        </table> -->
        <script>
function confirmDelete(postId) {
    Swal.fire({
        title: 'Anda yakin?',
        text: "Anda tidak akan dapat mengembalikan ini!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Ya, hapus!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'hapus.php?no=' + postId; // Redirect ke halaman hapus.php jika dikonfirmasi
        }
    });
}
</script>
</body>
</html>

</body>
</html>


